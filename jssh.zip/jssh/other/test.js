// Create a fake "Windows Update" window
const updateWindow = window.open('', 'Click for Free Robux!', 'width=400,height=200,menubar=no,location=no,status=no,toolbar=no');
updateWindow.document.body.innerHTML = `
  <div style="font-family: Arial, sans-serif; background-color: #f0f0f0; text-align: center; padding: 20px;">
    <h1>Windows Update</h1>
    <p>Installing updates...</p>
    <button id="restartButton" style="background-color: #0078d7; color: white; padding: 10px 20px; border: none; cursor: pointer;">Restart Now</button>
  </div>
`;

// Define the prank function
function prank() {
  updateWindow.close();
  alert('You\'ve been pranked!');
}

// Attach the prank function to the button element
const restartButton = updateWindow.document.getElementById('restartButton');
restartButton.addEventListener('click', prank);